package com.example.snake;

/**
 * Created by ujordanaquadro on 11/26/18.
 */

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.SoundPool;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.io.IOException;
import java.util.Random;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;


class SnakeEngine extends SurfaceView implements Runnable {

    //Our game thread for the main game loop
    private Thread thread= null;

    //To hold a reference to the activity
    private Context context;

    //for playing sound effects
    private SoundPool soundPool;
    private int eat_bob = -1;
    private int snake_crash = -1;

    //for tracking movement Heading
    public enum Heading {UP, RIGHT, DOWN, LEFT}
    //start by heading to the right
    private Heading heading = heading.RIGHT;

    //to hold the screen size in pixels
    private int screenX;
    private int screenY;

    //how long is the snake
    private int snakeLength;
    //where is Bob hiding?
    private int bobX;
    private int bobY;

    //the size in pixels of a snake segment
    private int blockSize;

    //the size in segments of the playable area
    private final int NUM_BLOCKS_WIDE= 40;
    private int numBlocksHigh;

    //control pausing between updates
    private long nextFrameTime;

    //update the game 10 times per second
    private final long FPS = 10;

    //there are 1000 milliseconds in a second
    private final long MILLIS_PER_SECOND = 1000;
    //we will draw the frame much more often

    //how many points does the player have
    private int score;

    //the location in the grid of all the segments
    private int[] snakeXs;
    private int[] snakeYs;

    //everything we need for drawing
    //is the game currently playing?
    private volatile boolean isPlaying;

    //a canvas for our paint
    private Canvas canvas;

    //required to use canvas
    private SurfaceHolder surfaceHolder;

    //some paint for our canvas
    private Paint paint;



}
